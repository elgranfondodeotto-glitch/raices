# Registro de aprendizajes · guionista-mamba v2

Actualizado: 6 nov 2026. Este archivo es memoria viva: cada vez que Otto apruebe o rechace un guion, se agrega una fila (ver "Cómo se alimenta" al final).

## Fuentes revisadas para esta versión

| Fuente | Estado |
|---|---|
| Skill guionista-mamba v1 (SKILL.md completo) | Leída |
| Skills editor-mamba, publicar-youtube, outreach-marcas | Leídas: sus reglas se heredan y no se contradicen |
| Doc "12 variaciones de tus reels de +1M" (3 nov 2026) | Leído completo |
| Doc "Reel Rockintor — informe y prompt" (1 nov 2026) | Leído completo |
| Hoja de precios Mamba (30 oct 2026, rev. 8) | Leída |
| Tablero Mamba (rev. 22) | Leído |
| Reels de @egfotto vía vidIQ (6 nov 2026): 12 reels con reproducciones, likes y comentarios | Leído |
| "Memoria de la skill Guionista Mamba" (6 nov 2026), aportada por Otto: reglas, sistema, casos aprobados, rechazos con su frase literal, marcas, flujo y datos vigentes | Leída e integrada en `memoria.md` (manda sobre este registro) |
| EDIT_SPEC.md de iCloud › Kits_Code (01–05) y Rockintor_Kit | No leídos directamente (el Mac no ofrece esas carpetas a sesiones en la nube); sus guiones aprobados están resumidos en `memoria.md` §4 |

Las frases literales de Otto vienen de su memoria (§5). Cuando un dato de este registro choque con `memoria.md`, manda `memoria.md`.

## Registro (3 columnas)

### A. Formatos y ganchos

| QUÉ FUNCIONÓ (evidencia) | QUÉ FALLÓ O RECHAZÓ OTTO | LA REGLA QUE SE DESPRENDE |
|---|---|---|
| **La bici de Blevins** (Lake Placid, 6 oct 2025): **1.021.470 reproducciones**, 53,4 mil likes. Una sola toma en mano, sin música ni texto, "la bicicleta del señor Christopher Blevins, ganador…", 2–3 rarezas tocadas en cámara (freno "apretado, apretado", llantas de gravel en XC). Copy en inglés etiquetando al piloto, al equipo y a SRAM. | — | **Receta "La bici del campeón"**: acceso exclusivo + un mito que se rompe EN CÁMARA (tocar, apretar, pellizcar) + specs rápidos + admiración. Si no hay mito comprobable, no se publica. Etiquetar al piloto, al equipo y a la marca. |
| **La bici de Vidaurre** (4 oct 2025): **714 mil reproducciones**, 300 comentarios (el que más conversación generó). "¡Máquinas! Bienvenidos a la Copa del Mundo…", detalle polémico ("el gravel se tomó el XCC"), cameo del pro. | — | **Receta "Hype en una toma"**: saludo explosivo + detalle polémico que divide opiniones (eso trae comentarios) + levantar la bici + cameo del dueño + grito final. |
| **«Contenido no apto para perfumados»** (adivina la bicicleta): +1M, 14 s, ojos vendados, rondas Downhill, Trail, XCO/XCM y «ROUT BIKE 🤢» (el error de ortografía también trajo comentarios). Remix aprobado 4A «¿Tú la adivinas?» (20 s, contador 3·2·1, «¿Cuántas adivinaste?»). | — | **Receta "Adivina a ciegas"**: 3 rondas legítimas + 1 absurda que les tira a los de ruta; 12–18 s; título amarillo; el remate es lo que se comparte. |
| **Charla "recuerda lo que dijo este CRACK"**: +1M (doc de 12 variaciones), 1:17, texto arriba + B-roll emotivo + monólogo + "felicitaciones" + orden de levantarse. | La voz original no era de Otto. | **Receta "Charla sobre B-roll"** con voz 100 % de Otto o de su podcast (nunca voz ajena ni IA): guardado y envío garantizados. |
| **Remixes del 5 nov 2026** con el mismo material de Lake Placid: Blevins con texto grande "La bici del #1" **34,4 mil**; bici de Blevins cruda **30,5 mil**; otra variación **13,4 mil**; Vidaurre con texto "El gravel se tomó el XCC" **7,6 mil**; ficha tipo videojuego de Vidaurre **2**. Es entre 1 % y 3 % de los originales. | Se publicaron 5 variaciones del mismo material **el mismo día**, y **todas con el mismo copy** ("30 segundos dentro de una Copa del Mundo"), que no describe lo que se ve en 4 de ellas. | 1) **Re-empaquetar no repite un viral**: lo que lo hizo explotar fue el acceso exclusivo en el momento (fin de semana de la Copa) y la etiqueta del piloto. 2) **Nunca más de una variación del mismo material por semana**; las pruebas de gancho van como **Trial Reels** y solo la ganadora se publica al perfil. 3) **Cada pieza lleva su propio copy**, escrito para ese video. 4) Los ganchos "de diseño" (ficha tipo videojuego: 2 reproducciones; mordiendo la llanta: 13 mil) rindieron menos que los que muestran a Otto con la bici y el nombre del piloto (30–34 mil): el gancho visual es la persona + la bici famosa, no el efecto. |
| **"Guárdalo para el día que quieras rendirte · Lo que me enseñó el Sahara"** (5 nov 2026): 2,6 mil en 1 día. | Publicado el mismo día que los 5 remixes (compitió con ellos). | La charla motivacional rinde con días de distancia de otros reels. Medirla por guardados y envíos, no por vistas del primer día. |
| **Reels de venta de la clínica de cierre** (6 nov 2026): español **1,6 mil**, inglés **1,0 mil**. "Quedan 3 cupos", $75, máx. 6. | — (es normal que un BOFU tenga poco alcance) | BOFU se mide por DMs, comentarios con palabra clave y ventas, no por vistas. La versión en español rinde más: la principal va en español, la inglesa es secundaria. La escasez solo si es real (verificar cupos el mismo día). |
| **"Nunca pongas tu bici AL REVÉS"** (YouTube, oct 2026): **102 mil vistas en 2 semanas, 143x el promedio**. "Cómo subir y bajar de la bici": 118 mil, 76 % de retención. | — | **Receta "Nunca pero nunca"**: el error se ve en el fotograma 1, título que nombra el error, corte en el remate, sin despedida. Es el tutorial que la gente guarda: el MOFU que más falta en Instagram (máximo 27 guardados por reel en ago–oct). |
| Historias personales en IG: "Día 1. Tres años…" 33 s de media y 129 comentarios; "Solo existen dos tipos de ciclistas…" 26 s. Voces en off aprobadas: «Lo que Colombia le hizo a mis patas» (1:24, bambuco con marimba elegido por Otto), «Lo que nadie te dice de la Titan Desert» (1:05), «6 años» (~1:19). | Reel 6 años con clips de logística y POV de iPhone: «Cero no me gustan estos clips». | Para conectar (MOFU), primera frase = conflicto personal fuerte. En historias sobre Otto, solo Otto en acción compitiendo, con calidad de cine. |
| "Calle pero elegante": 174 compartidos, el doble que cualquier otro reel. | — | Los reels de actitud y estilo son los más compartidos: TOFU de envío. |
| Colaboraciones con nombres grandes (Chris Froome, "La Mamba y el Pistolero", "Reté a un cuatro veces campeón del Tour"): lo que más seguidores trae. | — | TOFU de seguidores = colaboración o reto con alguien conocido. |
| — | Contenido de marca con cara de anuncio: Cyclist Pack 4 mil y 10 s; Bivo ASMR 3,8 mil y 9 s; EVT 2 mil; Danny's 1,9 mil; lanzamiento en inglés 1,7 mil y 6 s. | **La marca entra dentro de una historia**, nunca en el primer segundo, nunca como anuncio. |

### B. Contenido de marca (caso Rockintor AirVora)

| QUÉ FUNCIONÓ | QUÉ FALLÓ O RECHAZÓ OTTO | LA REGLA |
|---|---|---|
| Estructura copiada de un review que funciona (PGYTECH, 1:29): gancho sin voz → presentación → dolor personal → solución → detalles → cierre con la mano tapando el lente. ~40 % a cámara, ~60 % B-roll, humor cada 15–20 s, una idea por frase. | — | **Receta "Review estilo referencia"**: cuando Otto trae una referencia, se desmonta clip por clip y el guion se escribe en los mismos bloques (A presentación, B honestidad/dolor, C dato duro, D lo que me voló la cabeza, E cierre). |
| Guion en 5 bloques grabado en selfie con 2–4 tomas por bloque: permite elegir la mejor sin regrabar. | Tomas descartadas por tropiezos ("se están definiendo", "así que así buscas") y por decir "hacerles" en vez de "serles". | Los guiones de marca se escriben **en bloques cortos de 1–3 frases** para grabar cada uno por separado, con palabras fáciles de decir de corrido. |
| El guion final llevó datos concretos: 940 g, nivel 2, OrganProt3ct y el Premio de Innovación 2026 (este último **confirmado por Otto**). | Una toma decía **960 g** y otra **940 g**; el premio no aparecía en la reseña y hubo que confirmarlo con Otto antes de usarlo. | **Cero datos sin fuente**: cada cifra o premio del guion lleva su fuente (web de la marca, ficha técnica, correo). Si no se puede verificar, se dice "según la marca" o se quita. |
| Voz original de Otto, sin voz en off nueva ni IA. | — | El guion se graba con su voz; nunca se propone voz de IA. |
| Cierre: código **10MAMBA** en pantalla, link en el primer comentario fijado, colaborador @rockintor, etiqueta de colaboración pagada, copy B "Directo al dolor" (Tablero, publicación 10 nov). | — | El entregable de marca incluye: código verificado, link con ref, colaborador, etiqueta pagada y 2–3 copys para elegir. |

### C. Voz y estilo (reglas de Otto heredadas de v1, editor-mamba y outreach-marcas)

| QUÉ FUNCIONÓ | QUÉ RECHAZÓ OTTO | LA REGLA |
|---|---|---|
| "máquinas", "el diablo está en los detalles", "nada más y nada menos", "este cabrón", "¡y que viva el mountain bike, cabrones!", "madre mía", "lo que está bien hecho, está bien hecho": aparecen en los dos reels de +700 mil. | Frases acartonadas o de LinkedIn. | Escribir como habla Otto en los virales; las frases-sello son activos distintivos. |
| — | Expresiones religiosas. | Nunca ("gracias a Dios", "si Dios quiere"…). |
| — | Mencionar la lesión o la vuelta a competir en 2027 en contenido de marca. | Prohibido en marca. (La bici "Mamba 2027" sí se nombra: es el dream build.) |
| — | Hospital o camilla para dar lástima. | Solo sutil, estético y técnico. |
| Dream builds sin títulos ni textos, armado en orden real. | — | En un dream build el guion es solo de voz o de foley; nada de rótulos. |
| Intro directa en YouTube pierde ~33 %; intro tipo vlog pierde 45–68 %. | Preámbulos ("la Mamba está de vuelta", madrugadas, viaje). | YouTube largo: primera frase = tema o conflicto; gancho ≤ 20 s. |
| En Shorts, la mitad de la audiencia se va en los últimos segundos si hay despedida. | Despedidas y CTA hablados largos al final. | El Short termina en el remate (o en loop). El CTA va dentro del remate en ≤ 1 frase, o en pantalla y en el copy. |

### D. Sistema estratégico (nov 2026)

| QUÉ FUNCIONÓ | QUÉ FALLÓ | LA REGLA |
|---|---|---|
| Ficha de objetivo con preguntas de opción múltiple antes de escribir (v1). | "Hemos venido creando contenido todo igual y los resultados no son los esperados." | Cada pieza tiene UN objetivo de embudo, UNA persona, UN trabajo (JTBD), UN nivel de conciencia y UN CTA. |
| Proporción 2 TOFU + 2 MOFU + 1 BOFU por semana. | El 5–6 nov salieron 5 remixes TOFU + 2 BOFU + 1 motivacional en 48 h. | Antes de escribir, mirar el Tablero y lo publicado en la semana; si se rompe la proporción, avisar. |
| CTA según etapa: TOFU → envíos; MOFU → guardados; BOFU → comentario con palabra clave / DM / link; lealtad → referidos. | — | Un solo CTA, el de la etapa. |

### E. Rechazos con frase literal de Otto (de `memoria.md` §5)

| QUÉ FUNCIONÓ | QUÉ FALLÓ O RECHAZÓ OTTO | LA REGLA |
|---|---|---|
| Remixes aprobados sin grabar nada (1A, 2B, 3C, 4A) con copys de Trial Reel de 1–2 líneas. | «Quiero que generes variaciones sin tener yo que grabar nada nuevo» | **Modo remix**: cuando Otto pide variaciones, solo material existente; lo que exige grabar va aparte, como anexo. |
| Otto como único protagonista. | «Siempre asegúrate de que el que esté en el video sea yo, el hombre moreno, el hombre negro… solamente a mí» | En contenido sobre Otto, el único protagonista es Otto (los pros o alumnos son cameo o el héroe de una pieza de lealtad, nunca el protagonista de una pieza sobre él). |
| Preview con la voz real de los clips. | «El video tiene que ser con la voz de los clips» | Solo la voz real de Otto; nunca IA. |
| Kit para Code con EDIT_SPEC.md. | «No generes la edición… prepara la estructura de edición completa para Code» | El guionista entrega guion + kit para Code, no renders ni 4K. |
| Ritmo de 28–30 cortes como la referencia. | «18 clips me parecen muy poquitos, quiero entre 28 y 30» | Igualar el número de cortes y el ritmo de la referencia. |
| Dos reviews dedicados de Ravemen (uno por luz). | Se propuso meter el unboxing dentro del video de bicis de 32". | Un unboxing dentro de otro tema no cuenta como entregable; solo como extra. |
| Copy de la clínica corto y contundente (aprobado 5 nov). | — | Copys cortos; en Trial Reels, 1–2 líneas. |
| — | La música que «ya sirve». | Música curada para cada video. |

> **Secciones F–M · Guiones manuales de antes (2019–2024).** Otto los compartió para mostrar su estilo, su jerga y cómo se dirige a su público. **No son referencia de estructura para los guiones nuevos.** Lo que se aprende de ellos sobre la voz está en `voz-otto.md`; lo que cambia en la estructura está en estas tablas.

### F. Guiones manuales de antes (línea base) · «Guion para viajar a la Titan Desert Marruecos»

Otto lo escribió a mano a partir de las preguntas frecuentes oficiales de la Škoda Titan Desert Morocco. Sirve para medir el cambio: qué se conserva y qué cambia con el sistema.

| QUÉ FUNCIONA (se conserva) | QUÉ FALLA FRENTE AL SISTEMA | LA REGLA |
|---|---|---|
| La experiencia propia que la FAQ no tiene: «yo he viajado de las dos formas», ir por tierra desde Almería (+5 días ida y vuelta), la e-SIM «funciona al pelo», Willy Asistencias, «menos es más». Es lo único que nadie más puede contar. | Arranca con «lo primero es comprar los vuelos»: no hay gancho. | **El valor está en la experiencia de Otto, no en la FAQ.** La FAQ oficial es la fuente de los datos, no el guion. |
| Valor práctico real: tranquiliza al que quiere ir y no sabe cómo. | Copia la FAQ punto por punto (vuelos, haimas, bici, equipaje, comida, enchufes, cobertura, asistencia, ropa): todo pesa igual, no hay pico, no hay bucles. Son ~450 palabras (~3 min). | **Una idea por pieza.** De una FAQ salen: 1 Short con los 3 datos que más sorprenden + la experiencia de Otto, una serie de Shorts (uno por pregunta) y 1 video largo de YouTube con capítulos. |
| Tono cercano y con energía («¡Aventura total!», «menos es más»). | Emojis, negritas y viñetas dentro del texto hablado: el teleprompter no los lee. | En el guion hablado no van emojis, viñetas ni negritas; esos van en el texto en pantalla y en el copy. |
| — | No define etapa, persona ni CTA («ahí les dejo para que vengan a vivir…»). | Ficha primero. Si es MOFU, CTA de guardado; si Otto vende el viaje, BOFU con oferta verificada. |
| — | Datos que cambian cada edición (horarios, 20 kg + 5 kg, almacenes de Barcelona) sin año ni fuente. | Cada dato logístico lleva la edición y la fuente («según la organización, edición 2026») y se reconfirma antes de grabar. |
| — | Willy Asistencias aparece como recomendación. | Antes de nombrar una empresa, confirmar con Otto si hay acuerdo: si lo hay, se dice con transparencia; si no, se nombra como recomendación personal. |

### G. Guion manual de antes · YouTube largo «¿Rígida o doble?» (patrocinio INBIKE)

| QUÉ FUNCIONA (se conserva) | QUÉ FALLA FRENTE AL SISTEMA | LA REGLA |
|---|---|---|
| Frases con opinión fuerte que dividen y se recuerdan: «antes de comprarme una mala doble prefiero llevar una buena rígida», «un tema que levanta muchos callos y rompe corazones», la rígida en XCO como «un caballo cuarto de milla». | Arranca con preámbulo: «Heyy míguenle, bienvenidos una vez más a mi canal, y el día de hoy vamos a tocar un tema…». En los datos del canal, las intros así pierden 45–68 % en el primer minuto. | **La frase más polémica es el gancho.** La primera frase es el tema o el conflicto; el saludo va después y corto. |
| Ejemplos locales que solo Otto puede dar: Bogotá (vías en buen estado → rígida), Santander (el Engresque bajando a Zapatoca, los caminos de Lebrija, el matadero del Pato → doble), los Llanos (plano pero con piedra → doble). | El patrocinador entra **antes** de dar cualquier valor («antes de irnos a hablar… veámonos con el patrocinador»). | **Transparencia al inicio en una línea; el segmento del patrocinador va después del primer capítulo de valor y dentro de la historia** (ej.: INBIKE en el capítulo de maratón de 7 días, donde los calambres son el problema real). |
| Experiencia de primera mano con las dos bicis y un caso concreto (Epic Evo para La Leyenda del Dorado: +16.000 m de desnivel, 7 días). | Beneficios del patrocinador dichos como hechos («ayuda a prevenir calambres»). | Afirmaciones de salud o rendimiento de una marca van «según la marca», y Otto solo afirma lo que sintió él. |
| Pregunta a la comunidad para comentarios. | Cierre largo de despedida: «si les ha gustado dejen un gran like y si no también… chaooo». En Shorts la mitad se va con la despedida; en largos se pierde la tarjeta final. | Cierre = veredicto + una pregunta concreta («comenta R o D») + tarjeta al siguiente video + «más determinación, menos excusas». Sin «chao». |
| — | Estructura lineal sin capítulos con nombre; datos de época («9 o 10 velocidades») y bicis que ya pueden no ser las actuales. | Capítulos con nombre propio (terreno, carrera, presupuesto). Revisar qué bicis tiene Otto hoy (en nov 2026: dream build Mamba 2027, Specialized Epic 8) antes de citarlas. |
| — | Saludo «Heyy míguenle». | El saludo vigente es «buenas noches, buenas tardes, buenos días». |

**Patrón común de los guiones de antes (Titan y Rígida o doble):** empiezan por el principio y no por el gancho, siguen el orden de la información y no el de la emoción, ponen todo al mismo nivel sin pico, y cierran con despedida. Lo que más valor tiene en los dos es la experiencia personal y los ejemplos locales: **la skill parte siempre de ahí.**

### H. Texto de antes · «Olímpicos de París» (2024): versión de Otto vs. versión pulida

Otto escribió un texto crudo y existe una segunda versión «pulida». La comparación es la lección de voz más clara que hay.

| QUÉ FUNCIONA (versión de Otto) | QUÉ FALLA (versión pulida) | LA REGLA |
|---|---|---|
| Imágenes propias: «mi viejo era boxeador profesional», «se le notaban las ganas de estar en el cuadrilátero», «los galácticos, los súper humanos», «el extraterrestre de Usain Bolt», «la piel se pone tan chinita que dan ganas de llorar», «soy cursi, ya lo saben». | Frases genéricas que podría firmar cualquiera: «celebración de la humanidad», «el epicentro de esa magia», «determinación inquebrantable», «cumplir un sueño es un acto de valentía», «convertir lo imposible en posible», «déjame decirte», «surcar la pista». | **Cuando Otto trae su propio texto, se respetan sus frases.** Solo se reordena (gancho, pico, remate) y se recorta. Nunca se «pule» hacia un lenguaje genérico. |
| Honestidad concreta: «por alguna razón económica no se me daba». | La pulida lo vuelve abstracto: «el camino no fue fácil». | Lo concreto vence a lo abstracto: plata, años, nombres, lugares. |
| Un detalle de Storyworthy de oro: el papá boxeador viviendo Barcelona 92. | — | El detalle familiar abre la historia; es el gancho natural. |
| Momento de transformación claro: llegar a París y que sea «mucho más grande» de lo imaginado. | Las dos versiones cuentan en orden cronológico (1992 → 2008 → hoy). | Storyworthy: empezar cerca del momento del cambio o con la imagen más fuerte; el resto se cuenta rápido. |
| Cierre con «más determinación, menos excusas». | — | Activo distintivo al cierre. |

**Lista negra de frases acartonadas** (no se usan nunca en un guion de Otto): celebración de la humanidad · epicentro · magia (como relleno) · inquebrantable · acto de valentía · convertir lo imposible en posible · déjame decirte · surcar · sin lugar a dudas · en el mundo de hoy · viaje (como metáfora de vida) · pasión desbordante · llevar al siguiente nivel.

### I. Guion de antes · Entrevista «Semana de la Bicicleta» (Funza, Sabana de Occidente)

Respuestas preparadas para una entrevista o charla pública: apertura, tres preguntas y mensaje final.

| QUÉ FUNCIONA (se conserva) | QUÉ FALLA FRENTE AL SISTEMA | LA REGLA |
|---|---|---|
| La mejor frase está al final: «si alguien me hubiera dicho hace 10 años, cuando me subí a la bici, todos los beneficios que traería para mi vida, no le hubiera creído una sola palabra». Es un momento Storyworthy perfecto. | Abre con agradecimiento y felicitaciones formales, y luego con generalidades: «uno de los mejores inventos de la humanidad», «vehículo multimodal». | **La frase más fuerte va primero** (y se retoma al final para cerrar en círculo). El agradecimiento, en una línea. |
| Una idea propia y filosa: en Colombia la bici fue transporte mucho antes de los carriles bici, porque con un salario mínimo no alcanza ni para bus ni para moto. | Respuestas largas, con frases de varias líneas. | **Cada respuesta de entrevista: titular → prueba o experiencia → cierre.** 30–60 s, para que cada una sirva también como clip de reel (protocolo TEP de editor-mamba). |
| Autoridad por experiencia: comparar Nueva York con Bogotá desde lo que vio (carriles, bici pública, domicilios en bici eléctrica). | Cifras sin fuente: Nueva York y Bogotá «10 millones», «densidad similar», «miles de millones», «más de 2.000 viajes por hora entre Funza y Mosquera». | Toda cifra lleva fuente (estudio de movilidad, alcaldía, censo) o se dice como lo que es: «lo que vi», «más o menos». Población ≠ densidad. |
| Petición concreta a quien escucha: carril bici Funza–Siberia (y a Chía). | — | En una charla pública, una petición concreta vale más que diez generalidades. |
| «El ciclismo está en el ADN de los colombianos», «el que lo prueba se queda». | Cierre con lista genérica de beneficios («beneficios y bondades es lo que les sobra»). | Cierre con la imagen personal, no con la lista. |
| — | Texto en mayúsculas y con errores de tipeo. | En el teleprompter, ortografía limpia. ⚠️ Preguntar a Otto si lee mejor en mayúsculas; si sí, se respeta. |

### J. Guion de antes · YouTube largo «Cómo identificar tiendas confiables en AliExpress» (segunda parte)

| QUÉ FUNCIONA (se conserva) | QUÉ FALLA FRENTE AL SISTEMA | LA REGLA |
|---|---|---|
| **El tema salió de los comentarios:** después del video de AliExpress, la gente preguntó por los links de las tiendas. Es Jobs to Be Done puro: la audiencia dijo qué necesita. | Los primeros segundos mandan a la gente a otro video («te recomiendo que vayas a verlo… aquí te dejo la tarjeta»). | **Los temas que piden los comentarios son prioridad.** Pero la tarjeta a otro video nunca va en los primeros 20 s: va donde sea útil o al final. |
| Gracias públicas a quienes preguntaron y saludo a suscriptores con nombre (Fercho Molano, Carlos Lara): construye los 1.000 fans verdaderos. | Antes de dar valor hay: saludo «MI Genteee!!!!!», el contexto del video anterior, los saludos, el porqué del video y «si aún no me sigues…». Más de 30 s sin entrar al tema. | El reconocimiento a la comunidad va **en una línea, después del gancho**, o al final. Pedir que lo sigan, solo al final (o nunca: lo pide el contenido). |
| Valor práctico real (MOFU) y un tema con búsqueda constante. | Un link pegado dentro del texto hablado. | Los links nunca van en el guion hablado: van en la descripción o en el comentario fijado; en voz, «el link está en la descripción». |
| — | Datos de la plataforma (nombre del sello, criterios para otorgarlo) sin fecha. | Los programas de las plataformas cambian de nombre y de reglas: verificar el nombre y los criterios vigentes antes de grabar. Si hay links de afiliado, decirlo. |
| — | Tono de manual: «lo primero que debemos saber es que…», «analicemos cada una para que veamos de qué se trata». | Se dice como lo diría Otto en la rodada, con su experiencia: qué compró, qué le llegó, qué le salió mal. |

### K. Texto de antes · Mensaje a la comunidad de Año Nuevo (enero 2020)

| QUÉ FUNCIONA (se conserva) | QUÉ FALLA FRENTE AL SISTEMA | LA REGLA |
|---|---|---|
| El refrán más Otto de todos: **«hombre pelado no goza mujer bonita ni mucho menos bicicleta gama alta»**. También: «la bici no se mantiene sola», «andar de loco por Bucaramanga en la Mamba», «no deja mucho tiempo para la farándula». | Abre pidiendo disculpas por la ausencia («hace mucho tiempo no pasaba por aquí»): pone el foco en Otto y no en la comunidad. | En los mensajes de lealtad, **la línea más graciosa o más verdadera abre**; nunca la disculpa por no publicar. |
| Gratitud genuina a la comunidad (etapa de lealtad). | Deseos genéricos («feliz año lleno de buenas cosas») y agradecimiento sin nada concreto. | Agradecer con un momento o un dato concreto del año (una carrera, un alumno, una rodada). |
| Mira hacia adelante: arranca la temporada. | Cierre vago: «espero encontrarlos a todos por allí». La mejor frase queda enterrada al final. | Cierre con una pregunta que haga hablar a la comunidad («¿en qué carrera nos vemos?») y, si existe, dónde encontrarse (rodada, clínica). |

### L. Guion de antes · YouTube largo «SRAM Eagle AXS» con invitado (Pato Chávez, Specialized Bucaramanga)

| QUÉ FUNCIONA (se conserva) | QUÉ FALLA FRENTE AL SISTEMA | LA REGLA |
|---|---|---|
| Gancho con actitud y expresión propia: «para los que pensaban que lo habían visto todo… lamento defraudarlos, hoy les traigo **la mamá de los pollitos**». | Abre con «Bueno mi gente» antes de esa frase. | La frase con actitud va primero, sin muletilla antes. |
| Autoridad prestada: un invitado con credenciales concretas (líder de marca Specialized Bucaramanga, 27 años en MTB). | — | Presentar al invitado con 1–2 credenciales concretas, en una frase. |
| «Vamos al grano»: Otto sabe que hay que entrar rápido al tema. | — | Se conserva como transición. |
| Las preguntas son las que tiene la gente de verdad (baterías, viajar con la bici, lavado, IP69K, compatibilidad). Datos del canal: las curvas de retención **suben** cuando aparece una sección técnica con nombre propio (SRAM AXS, Lefty, SID Ultimate). | **19 preguntas seguidas, todas con el mismo peso**, sin capítulos, sin pico, sin veredicto y sin cierre. | **Agrupar las preguntas en 4–6 capítulos con nombre propio**, ordenados por interés (lo más buscado primero), y terminar con una pregunta de veredicto: «¿para quién vale la pena?». |
| — | Otto solo pregunta: no aporta su experiencia ni traduce lo técnico. | Otto es el guía del espectador: repregunta en palabras simples, cuenta su experiencia y cierra cada capítulo con un resumen de una frase. |
| — | Datos técnicos sin verificar (el guion dice «versión bluetooth»: AXS usa su propio protocolo inalámbrico; la app se conecta por Bluetooth). Producto presentado como «nuevo». | Verificar las specs con la marca antes de grabar; no decir «nuevo» si el video va a vivir años en búsqueda. Transparencia si hay relación con la marca (hoy existe un acuerdo pagado con SRAM/RockShox). |

### M. Guion de antes · YouTube «Qué ropa ponerse para ir en bici» (sección «No tenía ni idea»)

| QUÉ FUNCIONA (se conserva) | QUÉ FALLA FRENTE AL SISTEMA | LA REGLA |
|---|---|---|
| **El mejor gancho del guion está escondido después de la intro:** «la expresión más común de los que empiezan: me duele el culo… esa silla me cobró arriendo». Nombra el dolor exacto del principiante (conciencia del problema). | Antes del gancho van: «mi genteeee», la explicación de la sección, «yo soy Otto…» y «vamos al intro». | El dolor del espectador, dicho como lo dice él, es el gancho. Sin nada antes. |
| Humor propio que enseña: la badana «nos hace ver sexis y seductores… parece que nos hubiéramos hecho la cirugía de las nalgas», «si le duele hasta el pelo, ¿qué está esperando?», «el bronceado sexi del ciclista». | — | El humor va pegado al dato que enseña: así se recuerda. |
| Una serie con nombre («No tenía ni idea») = activo distintivo, como «Nunca pero nunca». | — | Las series con nombre se mantienen: el mismo nombre, el mismo título en pantalla y la misma estructura en cada capítulo. |
| Valor práctico real para el principiante: badana según horas (triatlón, ≤ 2 h para XC/DH, 3–4 h para maratón, 5 h o más para gran fondo), «la pregunta del millón», sin ropa interior, tirantes con broche para ellas, jersey con cremallera completa y bolsillo impermeable, manga según el clima (Cali vs Bogotá). | Pide like, suscripción y campana **a los 30 s y otra vez a mitad del video**, cortando el contenido. | **Nunca se pide like ni suscripción a mitad del video.** Al final y en una frase, o nada. |
| Le habla a las mujeres que empiezan y saluda a Mujeres al Pedal Bucaramanga (reto Bike Girl): comunidad y unidad. | El orden salta (la diferencia entre licra de hombre y de mujer aparece dentro de la sección de badanas). | Un capítulo por prenda, en el orden en que el principiante la compra. El dato más sorprendente («sin ropa interior») es el pico. |
| — | Apodo «el nazareno». | Es una referencia religiosa: no se usa (Otto es ateo y la regla es sin expresiones religiosas). «El señor caído» sí se puede. |
| — | Cierre largo («agradecerles a todos, el canal sigue creciendo…»). | Cierre: remate con la frase de la serie («si no tenías ni idea, ya no tienes excusa») + un CTA + activo distintivo. |

## Cómo se alimenta este registro (obligatorio en cada uso de la skill)

1. Cuando Otto diga "aprobado", "me gusta", "dale" o publique la pieza: agregar fila en QUÉ FUNCIONÓ con la fecha y, cuando existan, las métricas a 7 días.
2. Cuando Otto diga "no me gusta", "cero", "eso no", "muy acartonado" o pida cambios: copiar **su frase literal** en la columna del medio y escribir la regla.
3. Si falta contexto, en claude.ai buscar en la memoria y en los chats: guion, reel, telepromter, gancho, viral, +1M, "no me gusta", "cero", aprobado, Rockintor, Ravemen, Titan, Colombia, clínica, calas, "Nunca pero nunca", Mamba 2027, dream build, 6 años, Lake Placid, Blevins, Vidaurre, adivina la bicicleta, copy, Trial Reels, TOFU, Storyworthy.
4. Con el Mac conectado, leer los EDIT_SPEC.md de iCloud › Kits_Code (01_Colombia, 02_Titan_Desert, 03_Clinica_Calas, 04_Remix_virales, 05_Reel_6_anos) y Edición Rockintor › Rockintor_Kit, y pasar cada guion aprobado a `recetas.md` como ejemplo.
