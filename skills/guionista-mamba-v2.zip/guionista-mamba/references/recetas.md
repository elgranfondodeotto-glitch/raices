# Recetas probadas de Otto

Cada receta viene de una pieza real de Otto (evidencia en `registro-aprendizajes.md`). Se elige la receta según la ficha, se llena con el tema y se escribe en su voz. Si ninguna encaja, se usa la estructura de 8 piezas del SKILL.md.

Índice rápido por objetivo:

| Objetivo | Recetas |
|---|---|
| TOFU · alcance y envíos | 1 La bici del campeón · 2 Hype en una toma · 3 Adivina a ciegas · 4 "30 segundos en…" · 10 Actitud/estilo |
| TOFU · seguidores nuevos | 11 Colaboración o reto con alguien conocido |
| MOFU · guardados | 5 Nunca pero nunca · 6 Charla sobre B-roll · 7 Historia con aprendizaje · 14 Guía práctica de carrera · 15 Comparativa de decisión «¿X o Y?» · 20 Serie para principiantes «No tenía ni idea» |
| MOFU/BOFU · marca | 8 Review estilo referencia · 13 Review dedicado de YouTube |
| BOFU · ventas | 9 Short de venta (PAS) |
| Lealtad | 12 Celebrar al alumno · 18 Mensaje a la comunidad (Año Nuevo, gracias, regreso) |
| Autoridad y comunidad | 16 Entrevista, charla pública o invitado de podcast · 19 Entrevista con un experto (Otto anfitrión) |
| MOFU + lealtad | 17 Respondiendo a tus comentarios |

---

## 1 · La bici del campeón (TOFU) — base: Blevins, 1,02 M
- **Duración:** 60–95 s. **Producción:** una sola toma en mano, sin música ni texto (solo subtítulos). Sonido del lugar.
- **Estructura:** presentación con nombre y logro → "acabo de pillarme un detallito que me desmontó un mito" → mito 1 tocado en cámara → "pero lo que más me sorprende es…" (bucle) → mito 2 → specs rápidos (3) → detalle personal (bandera, nombre) → suspensión/levantar → admiración ("lo que está bien hecho, está bien hecho").
- **Plantilla:** "Aquí nada más y nada menos que la bicicleta del señor [nombre], ganador hoy de [carrera]. Pero este señor… acabo de pillarme un detallito que me desmontó un mito, ¿okay? Sientan esto: [mito 1]. Dura, dura. […] Pero lo que más me sorprende es [mito 2]. Lleva [spec], [spec] y [spec]. Y por aquí nos vamos a encontrar [detalle personal]. Madre mía: lo que está bien hecho, está bien hecho."
- **Condiciones:** el mito tiene que ser real y comprobable en cámara; si no hay mito, no se publica. Publicar en caliente (el mismo fin de semana de la carrera). Copy etiquetando al piloto, equipo y marcas, y enviar invitación de colaboración.
- **Variantes:** campeona (sube alcance y le habla a Rompe Tus Miedos), bici de $1.500 vs la del pro (mito = precio, MOFU de guardado).

## 2 · Hype en una toma (TOFU, comentarios) — base: Vidaurre, 714 mil y 300 comentarios
- **Duración:** 60–90 s, una toma, sin música.
- **Estructura:** "¡Máquinas! Sean ustedes bienvenidos a [evento]" → la bici o persona que llama la atención → el detalle "que solo se atreve este cabrón" (polémico: divide opiniones) → la levanta con una mano → "pero pónganle cuidado, que el diablo está en los detalles: acércate por aquí…" (detalle con historia) → cameo del dueño → "¡Y que viva el mountain bike, cabrones!".
- **Regla:** el detalle polémico es el motor de los comentarios; escríbelo para que la gente quiera discutirlo.

## 3 · Adivina a ciegas (TOFU, envíos) — base: «Contenido no apto para perfumados», +1 M (rondas Downhill, Trail, XCO/XCM y «ROUT BIKE 🤢»)
- **Duración:** 12–18 s. Cámara fija, ojos vendados, hip-hop con beat, título amarillo con destello "Adivina…".
- **Estructura:** 3 rondas legítimas (sonido real aislado + respuesta + etiqueta MAYÚSCULA con emoji) → ronda 4 absurda que les tira a los perfumados → audio cómico viral → (opcional) cuadro congelado "¿tú cuál hubieras adivinado? 👇".
- **Formato del guion:** tabla Ronda | Acción | Dices | Etiqueta (es la única receta donde se usa tabla).
- **Remix aprobado 4A «¿Tú la adivinas?»** (20 s): imagen congelada y contador 3·2·1 antes de cada respuesta; cierre «¿Cuántas adivinaste?».
- **Ideas probadas en papel:** la llanta por el sonido, el ciclista por el olor (remate: perfume = perfumado), el freno (remate: la chancla), la carrera por el paisaje, cuánto cuesta la bici (verificar precios reales).

## 4 · "30 segundos en…" (TOFU aspiracional → puente a BOFU de viajes)
- Remix aprobado 3C: montaje al beat a 128 BPM, apertura y cierre con los gritos del crudo de Vidaurre.
- Montaje de 30–45 s con saludo de hype al inicio, 6–8 escenas del lugar con sonido real, grito final, texto "AÑADE [X] A TU LISTA ✅".
- Si conecta con un producto (Mamba World Cup Experience, Sea Otter, Niágara), el CTA puede ser "comenta MUNDIAL" **solo si Otto confirma fecha y nombre del viaje** (aún no tiene precio en la Hoja de precios); si no, CTA de envío.
- Copy propio: "30 segundos dentro de una Copa del Mundo" se usa SOLO para este montaje, no para otras piezas.

## 5 · Nunca pero nunca (MOFU, guardados) — base: "Nunca pongas tu bici AL REVÉS", 102 mil en 2 semanas
- **Duración:** Short 30–60 s; versión YouTube hasta 3 min.
- **Estructura:** el error se VE en el fotograma 1 + "Nunca, pero nunca, [error]" → por qué es grave (consecuencia concreta, en plata o en caída) → cómo se hace bien (pasos numerados, 1 frase cada uno) → remate con una frase-sello → corte seco (loop si se puede).
- **Título:** "Nunca…", "Deja de…", "Cómo…". Mismos stickers y ritmo del Short original. Ningún sticker tapa la cara.
- **CTA:** "guárdalo para tu próxima rodada" dicho en ≤ 1 frase dentro del remate, o solo en pantalla y copy.

## 6 · Charla motivacional sobre B-roll (MOFU, guardados y envíos) — base: «Por si nadie te lo ha dicho. FELICITACIONES 🍾», +1 M (el podio y el abrazo con el coach)
- **Remix aprobado 1A «Nadie te dice»** (38 s): tramos de la voz de la Titan, B-roll del podio, CTA «guárdalo para el día que quieras rendirte».
- **Duración:** 35–75 s. Texto arriba que nombra el momento difícil ("cada vez que pienses en abandonar…") + B-roll de Otto con emoción real (podio, llegada, sufrimiento) + monólogo directo + clímax "felicitaciones" + orden de levantarse.
- **Voz:** siempre de Otto o de su podcast "El Arte de Saber Sufrir" (nunca voz ajena ni IA). Música de piano melancólico → esperanzador.
- **Persona:** una sola por guion ("el que entrena después de trabajar", "el que se cayó y le da miedo volver", "el que llegó de último").
- **Ejemplo de tono (borrador del 3 nov, no aprobado todavía):** "Si tú no te sientes orgulloso de ti, ¿quién lo va a hacer? […] Y «mañana» es el pueblo donde se mueren los sueños. […] Y por si nadie te lo ha dicho, te lo digo yo: felicitaciones. […] Felicitaciones: vales oro. Más determinación, menos excusas."
- **Publicación:** sola en su día (no junto a otros reels). Medir guardados.

## 7 · Historia con aprendizaje (MOFU, retención y comentarios) — base: "Día 1. Tres años…" (33 s de media, 129 comentarios), "Nadie te dice…" (Titan)
- Primera frase = conflicto personal fuerte ("Día 1…", "Nadie te dice…", "Solo existen dos tipos de ciclistas…", «ME FUI DE COLOMBIA… PERO COLOMBIA NUNCA SE FUE DE MIS PATAS 🇨🇴»).
- Aprobados con voz en off: «Lo que Colombia le hizo a mis patas» (1:24, bambuco con intro de marimba), «Lo que nadie te dice de la Titan Desert» (1:05), «6 años» (~1:19).
- Imágenes: **solo Otto en acción compitiendo, con calidad de cine**. Nada de clips de logística ni POV de iPhone («Cero no me gustan estos clips»).
- Storyworthy: empezar cerca del momento de 5 segundos del cambio, en presente, con apuestas claras.
- Para YouTube: empaquetar como "Lo que aprendí sufriendo [X]", no como diario. De cada historia larga salen 2–3 Shorts de problema → solución.

### Ejemplo: «Olímpicos de París» reescrito con el sistema (receta 7, reel de ~45 s con voz de Otto)
`TOFU/MOFU · Diana, 35, latina en Nueva York, tiene un sueño aplazado por plata · Trabajo: sentir que todavía puede · Conciencia: inconsciente · Receta 7 · Cialdini: simpatía + unidad · STEPPS: emoción + historias · CTA: envío · Métrica: envíos y retención`

GANCHO
Mi viejo era boxeador profesional. En Barcelona 92 lo vi vivir cada pelea como si estuviera en el cuadrilátero. [Plano: foto de archivo del papá o Otto de espaldas frente a los anillos olímpicos]

INTRO
Ese niño se enamoró de los Olímpicos. Y en Pekín 2008, viendo al extraterrestre de Usain Bolt, me prometí una cosa: algún día iba a estar ahí.

CUERPO
Y por años no se dio. La plata no alcanzaba. Pero aprendí algo: lo que uno quiere no cae del cielo. Si quiero que pase, tiene que ser mi única prioridad.

PICO
Hoy estoy en los Olímpicos de París. Y no es ni de cerca lo que me imaginé: es mucho más grande. Tengo la piel chinita y ganas de llorar. Soy cursi, ya lo saben.

REMATE + CTA
Así que sueñen, y sueñen en grande. Los apoyen o no, los sueños son suyos. Mándaselo al parcero que tiene un sueño guardado. Más determinación, menos excusas.

Texto en pantalla: «BARCELONA 92 → PARÍS 2024 🗼». ~125 palabras, ~50 s. Todas las frases son de Otto, solo reordenadas y recortadas. Si se publica hoy, el gancho cambia a pasado («Hace dos años cumplí…») o se guarda para Los Ángeles 2028.

## 8 · Review estilo referencia (marca) — base: Rockintor AirVora
- Cuando Otto trae un reel de referencia: desmontarlo (duración, cortes, % a cámara, tipo de planos, estructura) y escribir el guion en los mismos bloques.
- **Bloques para grabar en selfie, 1–3 frases cada uno, 2–4 tomas por bloque:**
  - A · Presentación + autoridad con humor ("si aún no conoces esta marca la estás cagando porque la están rompiendo").
  - B · Honestidad/dolor personal ("Máquinas, voy a serles totalmente honesto. Después de más de 10 años compitiendo…").
  - C · Dato duro verificado ("este bicho solo pesa 940 gramos").
  - D · "Pero ojito, que lo que realmente me voló la cabeza fue…" + "esto me lo van a agradecer".
  - E · Cierre de beneficio + "te dejo más información en la descripción" (código en pantalla).
- **Gancho sin voz** (unboxing rápido, 0–9 s) cuando la referencia lo tiene. El producto no es el gancho verbal: el gancho es la acción.
- **Cada dato con fuente**; si una toma dice una cifra distinta, se marca para no usarla. Premios y specs solo si están confirmados (el Premio de Innovación 2026 de Rockintor lo confirmó Otto).
- Ritmo de la referencia: si la referencia tiene 27 cortes, el reel va con 28–30 («18 clips me parecen muy poquitos»).
- Rockintor aprobado: 1:42, gancho sin voz con hyperlapse, copy B «Directo al dolor».
- Entregable extra: 2–3 copys (p. ej. A "Historia", B "Directo al dolor", C "Dato"), código, link con ref, colaborador y etiqueta pagada.

## 9 · Short de venta PAS (BOFU) — base: clínica de cierre, 6 nov
- **Duración:** 15–25 s (máximo 45 s si hay lista de lo que se aprende).
- **Estructura:** Gancho (problema visible o "Este domingo…") → Problema → Agitación (la escena concreta: "y cuando frenas tarde en el anillo del parque…") → Solución = la oferta con resultado soñado (Hormozi) → prueba (alumno, antes/después) → escasez REAL → CTA de conversión ("comenta CLÍNICA y te mando el link" / "escríbeme").
- **Datos obligatoriamente verificados el mismo día:** precio, fecha, hora, lugar, cupos restantes (Hoja de precios Mamba + Otto).
- Versión principal en español; la inglesa es secundaria.
- **Clínica «Las calas»** (1:01, aprobado): regala el truco primero (soltar la cala antes de parar, talón hacia afuera) y después vende. Testimonio: «No me he caído ni una sola vez».
- **Copy aprobado (5 nov):** «Este domingo 8 de nov 🔥 Clínica de técnica en Central Park · 9–11 am. Calas, frenado, curvas y posición. Para MTB, gravel y hasta perfumados 😏 $75 · máx. 6 personas · quedan 3 cupos. Escríbeme por WhatsApp o DM y separa el tuyo. Más determinación, menos excusas 🐍»
- Falta BOFU con testimonios: los alumnos de la clínica son el mejor TOFU y el mejor BOFU. Graba testimonios en cada clínica.

## 10 · Actitud y estilo (TOFU, compartidos) — base: "Calle pero elegante", 174 compartidos
- 10–20 s, una frase con actitud + look Mamba (jersey Leopardo/Mosaico, amarillo) + música con flow. Remate que la gente quiere mandar a su grupo.

## 11 · Colaboración o reto (TOFU, seguidores) — base: Froome / "La Mamba y el Pistolero" / "Reté a un cuatro veces campeón del Tour"
- Gancho = el nombre grande + el reto ("Reté a…"). Otto es el retador humilde con humor; el invitado es el gran nombre. Publicar como colaboración (los dos perfiles).

## 12 · Celebrar al alumno (lealtad y recomendación)
- El héroe es el alumno: antes (miedo, error) → el momento de 5 segundos del cambio → después. Con su permiso. CTA: "trae a un parcero" / "cuéntame tu logro".

## 13 · Review dedicado de YouTube (marca) — base: Ravemen FR1500 y CL200
- Un video por producto cuando el acuerdo dice "dedicado". Un unboxing dentro de otro tema no cuenta: solo como extra.
- Estructura de YouTube largo (SKILL.md): gancho ≤ 20 s con el problema que resuelve el producto → saludo → transparencia ("me lo mandó Ravemen para probarlo, opinión honesta") → unboxing de toda la caja (si aplica) → pruebas reales → lo que NO se puede mostrar se dice con honestidad (ej.: alcance de 115 m en estudio) → veredicto con pros y contras → link y código en voz y en la descripción.
- Cifras "según Ravemen" (o la marca que sea) cuando no se prueban en cámara. Grabación en estudio con las luces apagadas para las luces.

## 14 · Guía práctica «Lo que nadie te dice de ir a [carrera]» (MOFU, guardados; BOFU si Otto vende el viaje) — base: guion manual de la Titan Desert
- **Materia prima:** la FAQ oficial de la carrera (fuente de los datos) + la experiencia de Otto (el valor). Nunca se copia la FAQ punto por punto.
- **Corte:** 1 Short con los 3 datos que más sorprenden y un truco propio; el resto se reparte en una serie (un Short por pregunta) y en un video largo con capítulos (Vuelos · Campamentos · Bici · Equipaje · Comida · Comunicación · Asistencia).
- **Pico:** el dato que da miedo o sorprende (en la Titan, la etapa maratón).
- **Datos:** con año y fuente («según la organización»); reconfirmar antes de grabar.

### Ejemplo: el guion manual de la Titan, reescrito con el sistema (Short de ~40 s)
`MOFU · Andrés, 38, colombiano, quiere correr la Titan y la logística lo frena · Trabajo: quitarse el miedo logístico · Conciencia: del problema · Receta 14 · Cialdini: autoridad + reciprocidad · STEPPS: valor práctico + historias · CTA: guardado · Métrica: guardados`

GANCHO
En la Titan Desert te dan cama todas las noches… menos una. [Plano: Otto frente a una haima vacía]

INTRO
Máquinas, yo he corrido la Titan y les cuento tres cosas que nadie les dice antes de ir.

CUERPO 1
Desde Colombia, vuelen a Madrid o a Barcelona: de ahí salen los vuelos de la organización un día antes de la carrera. ¿Mi favorita? Por tierra desde Almería. Son cinco días más, pero se goza el doble.

BUCLE
Pero lo que más me sorprendió fue la comida.

CUERPO 2
Desayuno, almuerzo y cena van incluidos. Pero en carrera los avituallamientos son solo líquidos: las barritas y los geles, desde la casa.

BUCLE 2
Y ahora, la noche que les dije.

CUERPO 3 · PICO
La etapa maratón. Ahí desaparecen el colchón, las sábanas y la maleta. Duermes con lo que cargaste tú en la bici. Ahí no te ganan las patas: te gana la estrategia.

REMATE + CTA
Guárdalo para el día que te inscribas. Más determinación, menos excusas.

Texto en pantalla: «CAMA TODAS LAS NOCHES… MENOS UNA 🏜️». Duración: ~105 palabras, ~42 s. Datos según la FAQ de la organización: reconfirmar vuelos chárter, comidas incluidas y etapa maratón para la edición del año. ⚠️ Confirmar con Otto cuántas veces corrió la Titan antes de decir el número.
Lo que queda para la serie y el video largo: bici en camiones desde Barcelona, equipaje 20 kg + 5 kg en cabina, e-SIM, asistencia externa (Willy Asistencias), lavar ropa y «menos es más».

## 15 · Comparativa de decisión «¿X o Y?» (YouTube largo MOFU + Shorts TOFU) — base: guion manual «¿Rígida o doble?»
- **Por qué sirve:** el canal vive de la búsqueda (42 % de las vistas). Una duda de compra con nombre propio («rígida o doble», «29 o 27,5», «gravel o MTB») se busca todo el año.
- **Título** (< 60 caracteres, palabra clave al inicio): «Rígida o doble: cuál comprar según tu terreno».
- **Estructura:** gancho ≤ 20 s con la opinión más polémica → saludo corto → transparencia de marca en una línea → capítulos por criterio de decisión (qué es cada una · terreno · tipo de carrera · presupuesto) → el patrocinador dentro del capítulo donde resuelve un problema real → pico = el caso más extremo de Otto → veredicto en una frase por perfil → pregunta para comentarios → tarjeta al siguiente video.
- **De cada comparativa salen 2–3 Shorts:** la frase polémica (TOFU), el ejemplo regional (TOFU de envío: «mándaselo al parcero de Santander»), el criterio técnico (MOFU de guardado).

### Ejemplo: «¿Rígida o doble?» reescrito con el sistema (gancho y mapa)
`MOFU · Julián, 34, Bucaramanga, rueda una rígida y está ahorrando para cambiar de bici · Trabajo: no botar la plata en la bici equivocada · Conciencia: de la solución · Receta 15 · Cialdini: autoridad + simpatía · CTA: comentario «R o D» + video siguiente · Métrica: retención a 30 s y comentarios`

GANCHO (0–20 s)
Antes de comprarte una mala doble, cómprate una buena rígida. [Plano: las dos bicis lado a lado] Y sé que con esa frase ya me gané la mitad de los comentarios. Tengo las dos en el garaje y las he llevado al límite: en cross country, en maratones de siete días y en las trochas de Santander. Hoy les digo cuál necesitan según su terreno, su carrera y su bolsillo.

SALUDO
Buenas noches, buenas tardes, buenos días. Bienvenidos a El Gran Fondo De Otto. [Si hay marca:] Este video lo hacemos con INBIKE; opinión honesta, como siempre.

CAPÍTULOS
1. **Rígida y doble en 30 segundos:** rígida = suspensión adelante; doble = suspensión adelante y amortiguador atrás. (Las rígidas sin suspensión existen, pero no son el tema.)
2. **Según tu terreno:** Bogotá y vías en buen estado → rígida. Santander, el Engresque bajando a Zapatoca, los caminos de Lebrija, el matadero del Pato → doble. Los Llanos: «todo es plano, pero tiene más piedra que una cantera» → doble. Mini gancho: «y en competencia la cosa cambia».
3. **Según tu carrera:** XCO → la rígida es un caballo cuarto de milla: rápida y reactiva (aunque cada vez más corren con doble). Maratón y por etapas → la doble pasa de lujo a necesidad. [Patrocinador aquí: siete días seguidos, los calambres son el enemigo; INBIKE Ultra Endurance, lo que sintió Otto + beneficios «según INBIKE».]
4. **PICO · Mi caso extremo:** La Leyenda del Dorado: más de 16.000 metros de desnivel, siete días de candela y caminos sacados de una película de terror. [⚠️ Confirmar qué bici usó o usará; en nov 2026 la doble actual de Otto es la Mamba 2027, Specialized Epic 8.]
5. **Según tu bolsillo:** una mala doble es un problema: mantenimiento caro y difícil de arreglar en ruta. Por eso: antes de una mala doble, una buena rígida (el final empalma con el gancho).

VEREDICTO Y CIERRE
Terreno roto o carreras de varios días: doble. Terreno bueno, XCO o presupuesto justo: buena rígida. ¿Y tú cuál llevas? Comenta R o D. Y si quieres ver cómo se arma una doble de competencia, el dream build está aquí arriba. Más determinación, menos excusas. [2 s de aire]

⚠️ Verificar antes de grabar: bicis actuales de Otto, acuerdo vigente con INBIKE (entregable, código), producto exacto y datos de La Leyenda del Dorado.

## 16 · Entrevista, charla pública o invitado de podcast (autoridad y comunidad) — base: «Semana de la Bicicleta», Funza
- **Para:** entrevistas de prensa o de alcaldía, charlas, paneles, ser invitado en un podcast o preparar las respuestas de Otto en «El Arte de Saber Sufrir».
- **Apertura (≤ 15 s):** gracias en una línea + la frase más fuerte (confesión, historia o dato).
- **Cada respuesta (30–60 s):** titular en una frase → prueba (experiencia propia, lo que vio, un caso) → cierre que se pueda citar. Así cada respuesta sale como clip de reel.
- **Si hay una petición** (autoridades, marcas, comunidad), concreta: qué, dónde y por qué ahora.
- **Cierre:** volver a la frase de apertura (cierre en círculo) + «más determinación, menos excusas».
- **Cifras con fuente** o dichas como observación propia.

### Ejemplo: Funza reescrito con el sistema
`Autoridad/comunidad · Alcaldes y biciusuarios de la Sabana de Occidente · Trabajo: que la bici se tome en serio como transporte · Conciencia: del problema · Receta 16 · Cialdini: autoridad + unidad`

APERTURA
Gracias por la invitación. Y empiezo con una confesión: si hace diez años, cuando me subí a la bici, alguien me hubiera dicho todo lo que iba a hacer por mi vida, no le habría creído una sola palabra.

¿QUÉ HIZO CRECER A LOS AFICIONADOS?
Lo mejor que nos dejó la pandemia fue la bici: era de lo poco que se podía hacer, y se puede hacer solo. Pero ya venía creciendo: cada vez que un colombiano gana en una grande, miles salen a rodar. El ciclismo está en nuestro ADN. El que lo prueba, se queda.

¿CÓMO HA AYUDADO LA BICI A LAS CIUDADES?
Acabo de llegar de Nueva York. Allá todo gira alrededor del carro, y aun así están llenando la ciudad de carriles bici, bicis públicas y domicilios en bici eléctrica. La gente lo tiene claro: o te bajas del carro o se te va la vida en el tráfico. En Colombia es al revés: la bici fue transporte mucho antes del primer carril bici. ¿Por qué? Porque con un salario mínimo no alcanza para el bus ni para la moto. La bici fue el aliado de la gente cuando nadie hablaba de movilidad.
Por eso les pido a los alcaldes de la Sabana de Occidente: el carril bici de Funza a Siberia, y por qué no hasta Chía, es urgente. Entre Funza y Mosquera se mueven miles de viajes en bici en hora pico [⚠️ cifra exacta con fuente]. Hay ciudades enteras del país que no llegan a eso.

MENSAJE A LOS BICIUSUARIOS Y DEPORTISTAS
El ciclismo es más que un deporte: es un estilo de vida. Úsenla para ir al trabajo, para entrenar, para viajar o para rodar en familia. Hace diez años yo no le hubiera creído a nadie. Hoy se los digo yo: súbanse a la bici. Más determinación, menos excusas.

Clips que salen: «En Colombia la bici fue transporte antes que moda» (TOFU, envío) · «Si hace diez años me hubieran dicho…» (MOFU, historia).

## 17 · Respondiendo a tus comentarios (MOFU + lealtad) — base: «Tiendas confiables en AliExpress»
- **Cuándo:** una pregunta se repite en comentarios, DMs o en la clínica. Revisar comentarios de YouTube e Instagram (vidIQ: vidiq_comment_insights) para encontrar estos temas.
- **Gancho:** la pregunta tal como la hace la gente, en su idioma, con el miedo de fondo.
- **Saludo + gracias** en una línea a quien preguntó (nombre o usuario; si el comentario es público).
- **Cuerpo:** las N señales o pasos, cada uno con la experiencia de Otto (qué compró, qué le llegó, qué salió mal). Capítulos con nombre propio.
- **Pico:** la señal que nadie revisa o el error que le costó plata a Otto.
- **Cierre:** «si te quedó una duda, déjala en los comentarios: de ahí sale el próximo video» (cierra el volante) + tarjeta al video relacionado + «más determinación, menos excusas».
- **Shorts que salen:** «3 señales de una tienda confiable» (MOFU, guardado) y la experiencia que salió mal (TOFU).
- En Instagram, se puede responder al comentario con un reel (la respuesta aparece con el comentario de la persona).

### Ejemplo: inicio reescrito con el sistema (el guion original llega cortado en «Suspensión y frenos»)
`MOFU · Fercho, 29, quiere cambiar los frenos y la suspensión y no le alcanza para comprar en tienda · Trabajo: no perder la plata en un pedido · Conciencia: del problema · Receta 17 · Cialdini: reciprocidad + autoridad · CTA: guardado + pregunta en comentarios · Métrica: retención a 30 s, guardados y comentarios`

GANCHO (0–20 s)
¿Cómo sabes si una tienda de AliExpress te va a mandar la suspensión que pagaste… o un ladrillo? [Plano: celular con la tienda abierta y una caja de componente en la mesa] Después de mi video de AliExpress me llegaron [⚠️ número real] preguntas con esa misma duda. Hoy les muestro lo que reviso yo antes de comprar un componente.

SALUDO
Buenas noches, buenas tardes, buenos días. Bienvenidos a El Gran Fondo De Otto. Y gracias a Fercho Molano y a Carlos Lara, que preguntaron primero: este video es suyo.

CAPÍTULO 1 · El sello de tienda top
[Qué es, dónde se ve en la parte de arriba de la tienda y qué mide, según AliExpress: calidad del servicio, atención al cliente, entregas, posventa y reputación. ⚠️ Verificar el nombre y los criterios vigentes del programa.] El link está en la descripción.

CAPÍTULOS 2… · Por categoría: Suspensión y frenos · [resto de categorías del guion de Otto]
[Cada uno: qué tienda o señal revisa Otto + qué le llegó + lo que le salió mal.]

CIERRE
Si te quedó una duda, déjala en los comentarios: de ahí sale el próximo video. Y si quieres ver cómo les fue a mis amigos comprando por AliExpress, ese video está aquí. Más determinación, menos excusas. [Tarjeta al video anterior + 2 s de aire]

## 18 · Mensaje a la comunidad: Año Nuevo, gracias o regreso (lealtad) — base: mensaje de enero 2020
- **Formato:** post o reel corto a cámara (20–40 s), o copy largo.
- **Abre** con la línea más graciosa o más verdadera (un refrán de Otto, una confesión). Nunca con la disculpa por la ausencia.
- **Agradece** con un momento concreto del año.
- **Mira hacia adelante:** qué viene (temporada, carrera, clínica, viaje).
- **Cierra** con una pregunta a la comunidad + «más determinación, menos excusas».

### Ejemplo: el mensaje de 2020 reescrito con el sistema
`Lealtad · La comunidad que lo sigue desde Bucaramanga · Trabajo: sentirse parte · Receta 18 · Cialdini: simpatía + unidad · CTA: comentario · Métrica: comentarios`

Hombre pelado no goza mujer bonita, ni mucho menos bicicleta gama alta. Por eso volví a trabajar. [risa]
Y sí, extraño el año sabático y andar de loco por Bucaramanga en la Mamba con los parceros. Pero la bici no se mantiene sola.
Gracias por todo el apoyo del 2019: [⚠️ un momento concreto del año].
Ya arranca la temporada 2020. ¿En qué carrera nos vemos? Déjamelo en los comentarios.
Feliz año, máquinas. Más determinación, menos excusas.

## 19 · Entrevista con un experto, Otto como anfitrión (MOFU, autoridad) — base: «SRAM Eagle AXS» con Pato Chávez
- **Antes de grabar:** juntar las preguntas reales (comentarios, clínica, tienda), agruparlas en 4–6 capítulos con nombre propio y ordenarlas por interés. Agregar siempre la pregunta de veredicto.
- **Gancho (cold open, ≤ 20 s):** la respuesta más sorprendente del invitado (se elige en edición) + la frase con actitud de Otto + qué se lleva el espectador.
- **Presentación del invitado:** una frase con 1–2 credenciales concretas.
- **Transparencia** si hay relación con la marca.
- **Por capítulo:** Otto pregunta en palabras simples → el invitado responde → Otto repregunta lo que el espectador no entendió o aporta su experiencia → resumen de una frase. Un mini gancho de «lo que viene» al cambiar de capítulo.
- **Pico:** el veredicto del invitado («¿para quién vale la pena y para quién no?»).
- **Cierre:** gracias al invitado + pregunta a la comunidad + tarjeta + «más determinación, menos excusas».
- **Shorts que salen:** uno por capítulo (sobre todo el de mantenimiento/lavado y el de baterías: problema → solución).

### Ejemplo: «SRAM Eagle AXS» reorganizado con el sistema
`MOFU · Felipe, 40, Bucaramanga, rueda con Eagle mecánico y duda si pasarse a AXS · Trabajo: decidir sin botar la plata · Conciencia: de la solución · Receta 19 · Cialdini: autoridad + reciprocidad · CTA: comentario + video siguiente · Métrica: retención por capítulo`

GANCHO (≤ 20 s)
[Cold open: la respuesta más sorprendente de Pato, elegida en edición]
Para los que pensaban que lo habían visto todo en tecnología de montaña, lamento defraudarlos: hoy les traigo la mamá de los pollitos. SRAM Eagle AXS, cambios sin cables. Y le hice todas las preguntas que ustedes me hacen a alguien que lleva 27 años en la montaña.

SALUDO Y PRESENTACIÓN
Buenas noches, buenas tardes, buenos días. Bienvenidos a El Gran Fondo De Otto. Hoy está conmigo Pato Chávez, líder de marca de Specialized Bucaramanga [⚠️ confirmar cargo actual]. Vamos al grano.

CAPÍTULOS (las 19 preguntas de Otto, agrupadas)
1. **Qué cambia sin cables:** beneficios del sistema · versiones en el mercado · diferencia del tensor AXS con el Eagle mecánico · resistencia y durabilidad del tensor · diferencia de peso entre mecánico y AXS.
2. **Baterías:** duración de la batería del tensor y del mando · por qué tienen autonomía distinta · peso de la batería · cómo saber el nivel de carga · cuánto tarda en recargar.
3. **La app de SRAM, montaje y sincronización:** para qué sirve la app · cómo se monta y se sincroniza · el acelerómetro integrado.
4. **Viajar, lavar y mantener:** recomendaciones para viajar con la bici · lavado y mantenimiento de un sistema electrónico · qué es la norma IP69K.
5. **Compatibilidad:** accesorios AXS de montaña con AXS de ruta · con qué casete y qué plato viene.
6. **PICO · Veredicto (pregunta nueva):** ¿para quién vale la pena el AXS y para quién no?

CIERRE
Gracias, Pato. Y tú, ¿te pasarías al AXS o sigues con el mecánico? Déjamelo en los comentarios. Más determinación, menos excusas. [Tarjeta + 2 s de aire]

⚠️ Verificar con SRAM: autonomía, pesos, tiempos de carga, versiones y la norma IP69K. AXS usa su propio protocolo inalámbrico (no es «versión bluetooth»).

## 20 · Serie para principiantes «No tenía ni idea» (MOFU, guardados) — base: «Qué ropa ponerse para ir en bici»
- **Persona:** el que empieza (y la que empieza: incluir a las mujeres con ejemplos propios).
- **Gancho:** el dolor del principiante dicho con sus palabras («me duele el culo», «esa silla me cobró arriendo»).
- **Título en pantalla fijo:** «NO TENÍA NI IDEA · [tema]».
- **Bucle de apertura:** anunciar el error que comete casi todo el que empieza y dejarlo para el pico.
- **Capítulos:** uno por elemento, en el orden en que el principiante lo necesita. Cada dato con un chiste pegado.
- **Pico:** el dato que más sorprende al principiante.
- **Remate:** «si no tenías ni idea, ya no tienes excusa» + un CTA (guardado) + «más determinación, menos excusas».
- **Shorts que salen:** el pico como TOFU de curiosidad y la tabla práctica (por ejemplo, badana según horas) como MOFU de guardado.

### Ejemplo: «Qué ropa ponerse para ir en bici» reescrito con el sistema
`MOFU · Laura, 31, Bucaramanga, empezó a rodar hace un mes y le duele todo · Trabajo: dejar de sufrir en la silla sin gastar de más · Conciencia: del problema · Receta 20 · Cialdini: reciprocidad + simpatía · CTA: guardado · Métrica: guardados y retención`

GANCHO
«Me duele el culo.» «Esa silla me cobró arriendo.» Si estás empezando en la bici, ya lo dijiste. Y no, no es que yo tenga callo: es que elijo bien la ropa. [Texto: NO TENÍA NI IDEA · Qué ropa ponerse para ir en bici]

INTRO
Hoy les digo qué ponerse de las manos a los pies. Y al final de la badana les cuento el error que comete casi todo el que empieza.

SALUDO
Buenas noches, buenas tardes, buenos días. Y un saludo a las chicas de Mujeres al Pedal Bucaramanga [⚠️ confirmar si sigue vigente].

CAPÍTULOS
1. **Los tres puntos de contacto:** manubrio, silla y pedales. Ahí va la fuerza y ahí descarga el peso el cuerpo.
2. **Los guantes:** de tu talla; en montaña, de dedo completo, porque hay más riesgo de caída y más fuerza en las manos.
3. **La badana:** qué es («esa espuma que nos hace ver sexis y seductores… como si nos hubiéramos hecho la cirugía de las nalgas») · según las horas: triatlón (la más ligera) · hasta 2 h para XC y DH · 3–4 h para maratón · 5 h o más para gran fondo · la pregunta del millón: ¿puedo usar la de 5 horas siempre? Sí, pero es más gruesa y te quita agilidad en XC y DH. Si ya te duele hasta el pelo, ¿qué estás esperando?
   **PICO:** la badana va sin ropa interior. A pelo, sí señor. La ropa interior roza, abre heridas y no deja que la badana se acomode.
4. **La licra:** corta o larga (la larga evita el bronceado sexi del ciclista) · con o sin tirantes (para ellas, sin tirantes o con broche, por la ida al baño) · la de hombre es un poco más larga adelante.
5. **El jersey:** de tu talla (cada marca horma distinto) · tela de calidad, que no guarda olores · al menos un bolsillo impermeable para el celular y la plata · cremallera completa para los días de calor · manga según el clima: no es lo mismo Cali a las 6 de la mañana que Bogotá a 5 grados.

REMATE + CTA
Así que si no tenías ni idea, ya no tienes excusa. Guárdalo para tu próxima compra. Más determinación, menos excusas. [2 s de aire]
